CREATE TABLE cars (ID INT NOT NULL Primary Key AUTO_INCREMENT,make VARCHAR(50),model VARCHAR(50),color VARCHAR(50),price double, VIN VARCHAR(50),dealership VARCHAR(50));

INSERT INTO cars (make,model,color,price,VIN,dealership) VALUES
('bmw','525i','black',43999,'5YJSA1DG9DFP14705','towncenter'),
('Benz','c63','red',46999,'5YJSA1DG9CSP14789','lakeshore'),
('Toyota','supra','black',55999,'5HQSA1DG9DFP13805','lakeshore'),
('Nissan','GTR','orange',136999,'5YJSAPQC9DFP14705','downtown'),
('Honda','civic','white',25999,'5YJSA1DG9DFP13866','lakeshore'),
('audi','A6L','black',53999,'5YJSA1DG8CQP14705','towncenter'),
('Mitsubishi','evo 10','black',41999,'5YHNP1DG9DFP14705','lakeshore'),
('Nissan','R34','black',89999,'5YJSA1DG9DFP16665','lakeshore'),
('bmw','740li','black',92999,'5YJSA1PQ9DFP14705','downtown'),
('Benz','G63','black',113999,'5YCFA1DG9DFP14705','downtown');

CREATE TABLE dealerships (dealershipName VARCHAR(50) Primary Key);

INSERT INTO dealerships VALUES
('towncenter'),
('lakeshore'),
('downtown');