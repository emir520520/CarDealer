package ca.sheridancollege.database;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ca.sheridancollege.beans.Car;


@Repository
public class DatabaseAccess {
	
	@Autowired
	protected NamedParameterJdbcTemplate jdbc;
	
	DatabaseConfig dc=new DatabaseConfig(); 

	//-----------------------------------------dealership----------------------------------------------
		public ArrayList<String> getDealershipList() {
			JdbcTemplate jdbcTemplate=new JdbcTemplate(dc.dataSource());
			String query= "SELECT dealershipName FROM dealerships";

			ArrayList<String> dealershipList = (ArrayList<String>) jdbcTemplate.queryForList(query, String.class);
			return dealershipList;
		}
	
	//-----------------------------------------car-------------------------------------------------
	public ArrayList<Car> getTownCenterCars() {
		String query= "Select * from cars WHERE dealership=towncenter";
		ArrayList<Car> cars = (ArrayList<Car>)jdbc.query(query,new BeanPropertyRowMapper<Car>(Car.class));
		return cars;
	}
	
	public ArrayList<Car> getLakeShoreCars() {
		String query= "Select * from cars WHERE dealership=lakeshore";
		ArrayList<Car> cars = (ArrayList<Car>)jdbc.query(query,new BeanPropertyRowMapper<Car>(Car.class));
		return cars;
	}
	
	public ArrayList<Car> getDownTownCars() {
		String query= "Select * from cars WHERE dealership=downtown";
		ArrayList<Car> cars = (ArrayList<Car>)jdbc.query(query,new BeanPropertyRowMapper<Car>(Car.class));
		return cars;
	}
	
	public Car getCarByID(int ID){
		MapSqlParameterSource parameters=new MapSqlParameterSource();
		String query="SElECT * FROM cars WHERE ID=:ID";
		parameters.addValue("ID", ID);
		ArrayList<Car>cars=(ArrayList<Car>)jdbc.query(query, parameters, new BeanPropertyRowMapper<Car>(Car.class));

		if(cars.size()>0) {
			return cars.get(0);
		}else {
			return null;
		}
	}
	
	
	
	
	
	public void addCar(Car car) {
		MapSqlParameterSource parameters=new MapSqlParameterSource();
		String  query="INSERT INTO cars (make,model,color,price,VIN,dealership) VALUES(:make,:model,:color,:price,:VIN,:dealership)";
		parameters.addValue("make",  car.getMake());
		parameters.addValue("model",  car.getModel());
		parameters.addValue("color",  car.getColor());
		parameters.addValue("price",  car.getPrice());
		parameters.addValue("VIN",  car.getVin());
		parameters.addValue("dealership",  car.getDealership());
		jdbc.update(query, parameters);
	}
	
	
	
	public void editCar(Car car) {
		MapSqlParameterSource parameters=new MapSqlParameterSource();
		String  query="UPDATE cars SET make=:make, model=:model, color=:color, price=:price, Vin=:Vin, dealership=:dealership WHERE ID=:ID";
		parameters.addValue("make",  car.getMake());
		parameters.addValue("model",  car.getModel());
		parameters.addValue("color",  car.getColor());
		parameters.addValue("price",  car.getPrice());
		parameters.addValue("Vin",  car.getVin());
		parameters.addValue("dealership",  car.getDealership());
		parameters.addValue("ID", car.getID());
		jdbc.update(query, parameters);
	}
	
	
	public void deleteCar(int ID){
		MapSqlParameterSource parameters=new MapSqlParameterSource();
		String query="DELETE FROM cars WHERE ID=:ID";
		parameters.addValue("ID", ID);
		jdbc.update(query, parameters);
	}

	
	//--------------------------------------------search--------------------------------------
	public ArrayList<Car> searchByMake(String make){
		MapSqlParameterSource parameters=new MapSqlParameterSource();
		String query="SElECT * FROM cars WHERE make=:make";
		parameters.addValue("make", make);
		ArrayList<Car> cars=(ArrayList<Car>)jdbc.query(query, parameters, new BeanPropertyRowMapper<Car>(Car.class));
		
		return cars;
	}
	
	public ArrayList<Car> searchByID(int ID){
		MapSqlParameterSource parameters=new MapSqlParameterSource();
		String query="SElECT * FROM cars WHERE ID=:ID";
		parameters.addValue("ID", ID);
		ArrayList<Car> cars=(ArrayList<Car>)jdbc.query(query, parameters, new BeanPropertyRowMapper<Car>(Car.class));
		
		return cars;
	}
	
	public ArrayList<Car> searchByModel(String model){
		MapSqlParameterSource parameters=new MapSqlParameterSource();
		String query="SElECT * FROM cars WHERE model=:model";
		parameters.addValue("model", model);
		ArrayList<Car> cars=(ArrayList<Car>)jdbc.query(query, parameters, new BeanPropertyRowMapper<Car>(Car.class));
		
		return cars;
	}
	
	public ArrayList<Car> searchByPrice(double price1,double price2){
		MapSqlParameterSource parameters=new MapSqlParameterSource();
		String query="SElECT * FROM cars WHERE price BETWEEN :price1 AND :price2";
		parameters.addValue("price1", price1);
		parameters.addValue("price2", price2);
		ArrayList<Car> cars=(ArrayList<Car>)jdbc.query(query, parameters, new BeanPropertyRowMapper<Car>(Car.class));
		
		return cars;
	}
}
