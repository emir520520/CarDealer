package ca.sheridancollege.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import ca.sheridancollege.beans.Car;
import ca.sheridancollege.beans.Option;
import ca.sheridancollege.database.DatabaseAccess;

@Controller
public class HomeController {
	
	@Autowired
	private DatabaseAccess da;
	 
	//------------------------------------------home---------------------------------------------
	@GetMapping("/")
	public String goHome(Model model) {
		Car car=new Car();
		model.addAttribute("car",car);
		car.dealerships=da.getDealershipList();
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		model.addAttribute("dealerships", car.dealerships);
		
		return "addCar.html";
	}
	
	//-------------------------------------------car----------------------------------------------
	@GetMapping("/GoAddCar")
	public String goAddCar(Model model) {
		Car car=new Car();
		model.addAttribute("car",car);
		car.dealerships=da.getDealershipList();
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		model.addAttribute("dealerships", car.dealerships);

		return "addCar.html";
	}
		
	@GetMapping("/AddCar")
	public String addCar(Model model, @ModelAttribute Car car) {
		da.addCar(car);
		
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		ArrayList<Car> twoncenter = da.getTownCenterCars();
		ArrayList<Car> lakeshore = da.getLakeShoreCars();
		ArrayList<Car> downtown = da.getDownTownCars();
		model.addAttribute("twoncenter",twoncenter);
		model.addAttribute("lakeshore",lakeshore);
		model.addAttribute("downtown",downtown);
		return "viewCars.html";
	}
	
	@GetMapping("/ViewCar")
	public String getCars(Model model) {
		Car car=new Car();
		car.dealerships=da.getDealershipList();
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		model.addAttribute("dealerships", car.dealerships);
		ArrayList<Car> twoncenter = da.getTownCenterCars();
		ArrayList<Car> lakeshore = da.getLakeShoreCars();
		ArrayList<Car> downtown = da.getDownTownCars();
		model.addAttribute("twoncenter",twoncenter);
		model.addAttribute("lakeshore",lakeshore);
		model.addAttribute("downtown",downtown);
		return "viewCars.html";
	}

	@GetMapping("/edit/{ID}")
	public String goEditCar(Model model, @PathVariable int ID){
		Car car=new Car();
		car.dealerships=da.getDealershipList();
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		model.addAttribute("dealerships", car.dealerships);
		car= da.getCarByID(ID);
		car.dealerships=(ArrayList<String>) da.getDealershipList();
		model.addAttribute("car", car);
		return "editCar.html";
	}
	
	@GetMapping("/edit")
	public String editCar(Model model, @ModelAttribute Car car) {
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		da.editCar(car);
		ArrayList<Car> twoncenter = da.getTownCenterCars();
		ArrayList<Car> lakeshore = da.getLakeShoreCars();
		ArrayList<Car> downtown = da.getDownTownCars();
		model.addAttribute("twoncenter",twoncenter);
		model.addAttribute("lakeshore",lakeshore);
		model.addAttribute("downtown",downtown);
		return "redirect:/ViewCar";
	}
	
	@GetMapping("/delete/{ID}")
	public String deleteCar(Model model, @PathVariable int ID){
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		da.deleteCar(ID);
		return "redirect:/ViewCar";
	}
	
	@GetMapping("/purchase/{ID}")
	public String purchaseCar(Model model, @PathVariable int ID,@ModelAttribute Car car){
		
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		car=da.getCarByID(ID);
		double price=car.getPrice();
		car.taxes=price*0.13;
		car.totalPrice=price+car.taxes;
		model.addAttribute("car",car);
		
		da.deleteCar(ID);
		return "purchase.html";
	}
	
	//------------------------------------------search by make, model, ID--------------------------------------------
	@GetMapping("/search")
	public String searchCars(Model model,@RequestParam String option,@RequestParam String searchResult) {
		if(option.equals("ID")) {
			Car car=new Car();
			car.dealerships=da.getDealershipList();
			Option options=new Option();
			String[] optionList=options.getOptions();
			model.addAttribute("options",optionList);
			model.addAttribute("dealerships", car.dealerships);
			int ID=Integer.parseInt(searchResult);
			ArrayList<Car> carList=da.searchByID(ID);
			model.addAttribute("cars", carList);
			return "viewCars.html";
		}else if(option.equals("make")) {
			Car car=new Car();
			car.dealerships=da.getDealershipList();
			Option options=new Option();
			String[] optionList=options.getOptions();
			model.addAttribute("options",optionList);
			model.addAttribute("dealerships", car.dealerships);
			ArrayList<Car> carList=da.searchByMake(searchResult);
			model.addAttribute("cars", carList);
			return "viewCars.html";
		}else{
			Car car=new Car();
			car.dealerships=da.getDealershipList();
			Option options=new Option();
			String[] optionList=options.getOptions();
			model.addAttribute("options",optionList);
			model.addAttribute("dealerships", car.dealerships);
			ArrayList<Car> carList=da.searchByModel(searchResult);
			model.addAttribute("cars", carList);
			return "viewCars.html";
		}
	}
	
	//---------------------------------------------------search by price-----------------------------------------------------
	
	@GetMapping("/goSearchByPrice")
	public String goSearchByPrice(Model model) {
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		return "searchPrice.html";
	}
	
	@GetMapping("/SearchByPrice")
	public String searchByPrice(Model model,@RequestParam  double minPrice, @RequestParam double maxPrice) {
		Option options=new Option();
		String[] optionList=options.getOptions();
		model.addAttribute("options",optionList);
		ArrayList<Car> carList=da.searchByPrice(minPrice,maxPrice);
		model.addAttribute("cars", carList);
		return "viewCars.html";
	}
}
