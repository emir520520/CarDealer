package ca.sheridancollege.beans;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Car {
	
	private int ID;
	private String make;
	private String model;
	private String color;
	private double price;
	private String Vin;
	private String dealership;
	public double taxes;
	public double totalPrice;
	
	public ArrayList<String> dealerships;
}
